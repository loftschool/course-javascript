import './index.html';
import GeoReview from './geoReview';

new GeoReview();
